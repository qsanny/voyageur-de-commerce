print('python-3 OK')
