#include <fts.h>

int main(void)
{
	return 0;
}
